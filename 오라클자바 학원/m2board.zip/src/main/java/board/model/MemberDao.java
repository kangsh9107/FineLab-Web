package board.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class MemberDao { //Data Access Object
	
	private static MemberDao memberDao = null; //싱글톤 패턴으로 바꾸기 위해서 클래스 밖에서 참조할 객체를 만들어준다.
	private DataSource ds = null; //커넥션 풀
	
	
	
	private MemberDao() {
		try {
//			Class.forName("oracle.jdbc.OracleDriver"); //오라클 드라이버 존재 유무 확인. server.xml에서 확인가능
			Context context = new InitialContext();
			ds = (DataSource) context.lookup("java:comp/env/OracleCP");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	public static MemberDao getInstance() {
		if(memberDao == null) memberDao = new MemberDao();
		return memberDao;
	}
	
	
	
	private Connection getConnection() throws SQLException {
//		return DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xepdb1", "oraclejava", "oraclejava"); //"오라클 접속 url", "계정", "비밀번호"
		return ds.getConnection(); //미리 연결해둔 커넥션을 풀에서 가져온다.
	}
	
	
	
	private void dbClose(Connection cn, PreparedStatement ps, ResultSet rs) {
		if(rs != null) try { rs.close(); } catch(Exception e) {} //사용한 자원 역순으로 반환
		if(ps != null) try { ps.close(); } catch(Exception e) {}
		if(cn != null) try { cn.close(); } catch(Exception e) {}
	}
	
	
	
	private void dbClose(Connection cn, PreparedStatement ps) {
		if(ps != null) try { ps.close(); } catch(Exception e) {}
		if(cn != null) try { cn.close(); } catch(Exception e) {}
	}

}
