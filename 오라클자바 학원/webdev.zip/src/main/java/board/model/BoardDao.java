package board.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class BoardDao { //Data Access Object
	
	private static BoardDao boardDao = null; //싱글톤 패턴으로 바꾸기 위해서 클래스 밖에서 참조할 객체를 만들어준다.
	private DataSource ds = null; //커넥션 풀
	
	
	
	private BoardDao() {
		try {
//			Class.forName("oracle.jdbc.OracleDriver"); //오라클 드라이버 존재 유무 확인. server.xml에서 확인가능
			Context context = new InitialContext();
			ds = (DataSource) context.lookup("java:comp/env/OracleCP");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	public static BoardDao getInstance() {
		if(boardDao == null) boardDao = new BoardDao();
		return boardDao;
	}
	
	
	
	private Connection getConnection() throws SQLException {
//		return DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xepdb1", "oraclejava", "oraclejava"); //"오라클 접속 url", "계정", "비밀번호"
		return ds.getConnection(); //미리 연결해둔 커넥션을 풀에서 가져온다.
	}
	
	
	
	private void dbClose(Connection cn, PreparedStatement ps, ResultSet rs) {
		if(rs != null) try { rs.close(); } catch(Exception e) {} //사용한 자원 역순으로 반환
		if(ps != null) try { ps.close(); } catch(Exception e) {}
		if(cn != null) try { cn.close(); } catch(Exception e) {}
	}
	
	
	
	private void dbClose(Connection cn, PreparedStatement ps) {
		if(ps != null) try { ps.close(); } catch(Exception e) {}
		if(cn != null) try { cn.close(); } catch(Exception e) {}
	}
	
	
	
	public boolean insretBoard(BoardDto boardDto) {
		Connection cn = null;
		PreparedStatement ps = null;
		boolean result = false;
		
		String sql = "INSERT INTO m1board(no, title, name, password, content) "
				   + "VALUES(m1board_seq.nextval, ?, ?, ?, ?) ";
		
		try {
			cn = getConnection();
			ps = cn.prepareStatement(sql);
			ps.setString(1, boardDto.getTitle());
			ps.setString(2, boardDto.getName());
			ps.setString(3, boardDto.getPassword());
			ps.setString(4, boardDto.getContent());
			if(ps.executeUpdate() > 0) result = true; //select일 경우 ps.executeQuery();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			dbClose(cn, ps);
		}
		
		return result;
	}
	
	
	
	public boolean updateBoard(BoardDto boardDto) {
		Connection cn = null;
		PreparedStatement ps = null;
		boolean result = false;
		
		String sql = "UPDATE m1board "
				   + "SET title = ?, name = ?, content = ? "
				   + "WHERE no = ? AND password = ?";
		
		try {
			cn = getConnection();
			ps = cn.prepareStatement(sql);
			ps.setString(1, boardDto.getTitle());
			ps.setString(2, boardDto.getName());
			ps.setString(3, boardDto.getContent());
			ps.setLong(4, boardDto.getNo());
			ps.setString(5, boardDto.getPassword());
			if(ps.executeUpdate() > 0) result = true;
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			dbClose(cn, ps);
		}
		
		return result;
	}
	
	
	
	public boolean deleteBoard(BoardDto boardDto) {
		Connection cn = null;
		PreparedStatement ps = null;
		boolean result = false;
		
		String sql = "DELETE FROM m1board "
				   + "WHERE no = ? AND password = ? ";
		
		try {
			cn = getConnection();
			ps = cn.prepareStatement(sql);
			ps.setLong(1, boardDto.getNo());
			ps.setString(2, boardDto.getPassword());
			if(ps.executeUpdate() > 0) result = true;
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			dbClose(cn, ps);
		}
		
		return result;
	}



	public List<BoardDto> getBoardList() {
		Connection cn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<BoardDto> list = new ArrayList<>();
		
		String sql = "SELECT no, title, name, to_char(writeday, 'YYYY-MM-DD') AS writeday, readcount "
				   + "FROM m1board "
				   + "ORDER BY no DESC ";
		
		try {
			cn = getConnection();
			ps = cn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				BoardDto boardDto = new BoardDto();
				boardDto.setNo(rs.getLong("no"));
				boardDto.setTitle(rs.getString("title"));
				boardDto.setName(rs.getString("name"));
				boardDto.setWriteday(rs.getString("writeday"));
				boardDto.setReadcount(rs.getInt("readcount"));
				list.add(boardDto);
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			dbClose(cn, ps, rs);
		}
		
		return list;
	}
	
	
	
	public BoardDto getBoardView(Long no) {
		Connection cn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		BoardDto boardDto = null;
		
		String sql = "SELECT no, title, name, content, writeday, readcount "
				   + "FROM m1board "
				   + "WHERE no = ? ";
		
		try {
			cn = getConnection();
			ps = cn.prepareStatement(sql);
			ps.setLong(1, no);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				boardDto = new BoardDto();
				boardDto.setNo(rs.getLong("no"));
				boardDto.setTitle(rs.getString("title"));
				boardDto.setName(rs.getString("name"));
				boardDto.setContent(rs.getString("content"));
				boardDto.setWriteday(rs.getString("writeday"));
				boardDto.setReadcount(rs.getInt("readcount"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			dbClose(cn, ps, rs);
		}
		
		return boardDto;
	}
	
	
	
	public boolean updateReadcount(Long no) {
		boolean result = false;
		Connection cn = null;
		PreparedStatement ps = null;
		
		String sql = "UPDATE m1board "
				   + "SET readcount = readcount + 1 "
				   + "WHERE no = ? ";
		
		try {
			cn = getConnection();
			ps = cn.prepareStatement(sql);
			ps.setLong(1, no);
			if(ps.executeUpdate() > 0) result = true;
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			dbClose(cn, ps);
		}
		
		return result;
	}

}
