package board.model;

public class BoardDto { //Data Transfer Object, Vo (Value Object)

	private Long no;
	private String title;
	private String name;
	private String password;
	private String content;
	private String writeday;
	private Integer readcount; //기본 자료형이어도 상관없다
	public Long getNo() { return no; }
	public void setNo(Long no) { this.no = no; }
	public String getTitle() { return title; }
	public void setTitle(String title) { this.title = title; }
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }
	public String getPassword() { return password; }
	public void setPassword(String password) { this.password = password; }
	public String getContent() { return content; }
	public void setContent(String content) { this.content = content; }
	public String getWriteday() { return writeday; }
	public void setWriteday(String writeday) { this.writeday = writeday; }
	public Integer getReadcount() { return readcount; }
	public void setReadcount(Integer readcount) { this.readcount = readcount; }
	
	@Override
	public String toString() {
		return "Dto : [title : " + title + ", name : " + name + ", password : " + password + ", content : " + content + "]";
	}
	
}
