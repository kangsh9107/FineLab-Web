package oop03.modifier;

public class Point2D {
	
//	private int x;
	protected int x;
	int y;
	
	@Override
	public String toString() {
		return "Point2D [x=" + x + ", y=" + y + "]";
	}
	
}
