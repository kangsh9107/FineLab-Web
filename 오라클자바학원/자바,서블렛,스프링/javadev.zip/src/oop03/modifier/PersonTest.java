package oop03.modifier;

import oop02.static03.Person;

public class PersonTest {
	
	public static void main(String[] args) {
		Person p1 = new Person("안현수", "Korean");
		Person p2 = new Person("김연아", "Korean");
		System.out.println(p1.toString());
		System.out.println(p2.toString());
		
		System.out.println("-".repeat(30));
		
		p1.setName("빅토르 안");
		p1.setNation("Russian");
		System.out.println(p1.toString());
		System.out.println(p2.toString());
	}

}
