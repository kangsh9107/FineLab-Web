package oop03.modifier;

public class Point3D extends Point2D {
	
	int z;
	
	public void test() {
		System.out.println(x); //private이라 같은 클래스에서만 접근가능
	}
}
