package oop01.object;

public class PointTest {

	public static void main(String[] args) {
//		Point2D pt = new Point2D();
//		pt.x = 10;
//		pt.y = 20;
//		System.out.println("x : " + pt.x);
//		System.out.println("y : " + pt.y);
		
		//캡슐화
//		Point2D pt = new Point2D();
//		pt.setX(10);
//		pt.setY(20);
//		System.out.println("x : " + pt.getX());
//		System.out.println("y : " + pt.getY());
		
		//상속. Point3D에 x, y관련 내용 작성안해도 Point2D에서 상속받은 내용을 사용 가능
//		Point3D pt = new Point3D();
//		pt.setX(10);
//		pt.setY(20);
//		pt.setZ(30);
//		System.out.println("x : " + pt.getX());
//		System.out.println("y : " + pt.getY());
//		System.out.println("z : " + pt.getZ());
		
		//메소드 오버라이딩(Overriding)
//		Point3D pt = new Point3D();
//		pt.setX(10);
//		pt.setY(20);
//		pt.setZ(30);
//		pt.print();
		
		//생성자
//		Point2D pt1 = new Point2D();
//		pt1.print();
//		Point2D pt2 = new Point2D(10, 20);
//		pt2.print();
		Point3D pt3 = new Point3D();
		pt3.print();
//		Point3D pt4 = new Point3D(100, 200, 300);
//		pt4.print();
	}

}
