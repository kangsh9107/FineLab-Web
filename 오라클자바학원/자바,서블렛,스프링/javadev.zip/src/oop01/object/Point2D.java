package oop01.object;

public class Point2D {
//	int x;
//	int y;
	
	//캡슐화
	private int x;
	private int y;
	public int getX() { return x; }
	public void setX(int x) { this.x = x; }
	public int getY() { return y; }
	public void setY(int y) { this.y = y; }
	
	public void print() {
		System.out.println("x : " + getX());
		System.out.println("y : " + getY());
	}
	
	//생성자
	public Point2D() {
//		x = 1;
//		y = 2;
		
		this(1, 2); //인트 타입 매개변수 2개를 가지는 생성자 호출. 가장 첫 줄에 작성한다.
		System.out.println("Point2D() 수행 중");
	}
	
	public Point2D(int x, int y) {
		this.x = x;
		this.y = y;
		System.out.println("Point2D(x, y) 수행 중");
	}
	
}
