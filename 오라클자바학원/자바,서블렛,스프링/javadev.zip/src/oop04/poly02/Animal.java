package oop04.poly02;

public class Animal {

	public void eat() {
		System.out.println("맛있게 먹습니다.");
	}
	
	public void sleep() {
		System.out.println("잠을 잡니다.");
	}
	
}
