package oop04.poly02;

public class AnimalTest {

	public static void main(String[] args) {
//		Dog d = new Dog();
		Animal a = new Dog();
		a.eat();
		a.sleep();
//		a.bark();
		
		Dog d = (Dog)a;
		d.eat();
		d.sleep();
		d.bark();
	}

}
