package oop04.poly02;

public class Cat extends Animal {

	public void jump() {
		System.out.println("고양이가 점프합니다.");
	}
	
}
