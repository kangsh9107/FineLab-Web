package oop04.poly02;

public class Tiger extends Animal {

	public void attack() {
		System.out.println("호랑이가 공격합니다.");
	}
	
}
