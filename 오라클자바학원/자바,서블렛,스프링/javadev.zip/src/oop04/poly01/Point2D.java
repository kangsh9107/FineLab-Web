package oop04.poly01;

public class Point2D {

	int x;
	int y;
	
}
