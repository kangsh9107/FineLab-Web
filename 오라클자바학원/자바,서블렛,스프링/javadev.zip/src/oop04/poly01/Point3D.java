package oop04.poly01;

public class Point3D extends Point2D {
	
	int z;
	
}
