package oop04.poly01;

public class PointTest {
	
	public static void main(String[] args) {
		//다형성. 상위클래스를 참조타입으로 사용가능.
		
		//Upcasting
		//x, y, z를 다 가지고 있지만 x, y만 있는 Point2D타입으로 인식한다.
		//객체는 그대로인데 컴파일러가 다른 타입으로 인식한거다.
		Point2D up = new Point3D();
		up.x = 10;
		up.y = 20;
//		up.z = 30;
		
		//Downcasting
		Point3D dn = (Point3D)up;
		dn.x = 1000;
		dn.y = 2000;
		dn.z = 3000;
	}

}
