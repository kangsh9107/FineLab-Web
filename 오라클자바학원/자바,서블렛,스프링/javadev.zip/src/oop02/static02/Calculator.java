package oop02.static02;

public class Calculator {
	
	static double pi = 3.14159;
	
	public static int plus(int x, int y) {
		return x + y;
	}
	
	public static int minus(int x, int y) {
		return x - y;
	}
	
}
