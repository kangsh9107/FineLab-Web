package oop02.static03;

import oop03.modifier.Point2D;

public class PointTest {
	
	public static void main(String[] args) {
//		Point2D pt = new Point2D();
//		pt.x = 10; //private이라 같은 클래스에서만 접근가능.
	}
	
}
