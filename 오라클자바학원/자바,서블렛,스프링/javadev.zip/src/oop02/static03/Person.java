package oop02.static03;

public class Person {
	
	private String name;
	private static String nation;
	
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }
	public String getNation() { return nation; }
	public void setNation(String nation) { this.nation = nation; }
	
	@Override
	public String toString() {
		return "Person [name=" + name + ", nation=" + nation + "]";
	}
	
	public Person(String name, String nation) {
		super(); //여기서는 없어도 상관없다
		this.name = name;
		this.nation = nation;
	}
	
}
