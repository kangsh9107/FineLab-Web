package basic;

public class ContinueTest01 {

	/*
	 * continue 이하의 문장들은 생략하고 바로 증감식으로 이동
	 */
	public static void main(String[] args) {
		int sum1 = 0;
		int sum2 = 0;
		for(int i=1; i<=10; i++) {
			sum1 += i;
			
			if(i % 3 != 0) continue;
			sum2 += i;
		}
		System.out.println("1부터 10까지 합계는 " + sum1);
		System.out.println("1부터 10까지 3의 배수의 합계는 " + sum2);
	}

}
