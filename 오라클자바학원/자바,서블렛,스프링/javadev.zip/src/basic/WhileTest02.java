package basic;

public class WhileTest02 {

	public static void main(String[] args) {
//		int sum = 0;
//		for(int i=1; i<=1000; i++) {
//			if(i % 3 == 0) sum += i;
//		}
//		System.out.println("1부터 1000까지 3의 배수의 합은 : " + sum);
		
		//for문을 while문으로 변경
		int sum = 0;
		int i = 0;
		while(i <= 1000) {
			sum += i;
			i += 3;
		}
		System.out.println("1부터 1000까지 3의 배수의 합은 : " + sum);
		
//		int sum = 0;
//		int i = 1;
//		while(i <= 1000) {
//			if(i % 3 == 0) sum += i;
//			i++;
//		}
//		System.out.println("1부터 1000까지 3의 배수의 합은 : " + sum);
	}

}
