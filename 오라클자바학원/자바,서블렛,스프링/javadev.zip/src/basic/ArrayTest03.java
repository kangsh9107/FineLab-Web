package basic;

public class ArrayTest03 {

	//컨트롤 + 쉬프트 + F = 전체 코드 정리
	//드래그 후 하면 그 부분만 코드 정리
	public static void main(String[] args) {
		int[][] score = {
				{100, 90, 80, 70},
				{90, 80, 70, 60},
				{80, 70, 60, 50}
		};
//		System.out.println("score의 길이 : " + score.length);
		
		System.out.println("\t\t[성적표]");
		System.out.println("=".repeat(45));
		System.out.println("국어\t영어\t수학\t철학\t총점\t평균");
		for(int row=0; row<score.length; row++) {
			double tot = 0;
			for(int col=0; col<score[row].length; col++) {
				System.out.print(score[row][col] + "\t");
				tot += score[row][col];
			}
			System.out.println(tot + "\t" + (tot / score[row].length));
		}
		System.out.println("=".repeat(45));
	}

}
