package basic;

import java.util.Scanner;

public class OpTest01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); //System.in은 콘솔입력 또는 표준입력이다. 즉 키보드 입력을 의미한다.
		System.out.print("정수 a값 입력 : ");
		int a = sc.nextInt();
		System.out.print("정수 b값 입력 : ");
		int b = sc.nextInt();
		
		
		
//		int a = 7;
//		int b = 4;
		System.out.println(a + "+" + b + "=" + a + b);   //숫자를 문자열과 +연산하면 문자열이 된다.
		System.out.println(a + "+" + b + "=" + (a + b));
		System.out.println(a + "-" + b + "=" + (a - b));
		System.out.println(a + "*" + b + "=" + (a * b));
		System.out.println(a + "/" + b + "=" + (a / b)); //정수 나누기 정수는 정수타입으로 나온다.
		System.out.println(a + "%" + b + "=" + (a % b));
		sc.close(); //사용한 자원 반납
	}

}
