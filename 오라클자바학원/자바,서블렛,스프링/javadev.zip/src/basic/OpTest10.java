package basic;

public class OpTest10 {

	public static void main(String[] args) {
		//4~15 사이의 정수 발생
//		System.out.println((int)(Math.random() * 12) + 4);
		
		//600~2300 사이의 100단위 정수 발생
//		System.out.println((int)(((Math.random() * 18)) + 6) * 100);
		
		//200~1000 사이의 100단위 정수 발생
//		System.out.println((int)((Math.random() * 9) + 2) * 100);
//		for(int i=0; i<1000; i++) {
//			int a = (int)((Math.random() * 9) + 2) * 100;
//			if(a >= 1000) System.out.println(a);
//		}
		
		//20~100 사이의 20단위 정수 발생
		System.out.println((int)((Math.random() * 5) + 1) * 20);
		for(int i=0; i<1000; i++) {
			int a = (int)((Math.random() * 5) + 1) * 20;
			if(a <= 40) System.out.println(a);
		}
	}

}
