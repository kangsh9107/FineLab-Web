package basic;

public class OpTest09 {

	public static void main(String[] args) {
		//자동 형변환. promotion
		double d = 10;
		System.out.println(d);
		
		//강제 형변환. casting
		int i = (int)3.141592;
		System.out.println(i);
		
		System.out.println(Math.random());
		System.out.println(Math.random());
		System.out.println(Math.random());
		
		//Math.random()에 전체 가지수를 곱하고, 시작수를 더한다.
		System.out.println((int)(Math.random() * 6) + 1); //1~6
	}

}
