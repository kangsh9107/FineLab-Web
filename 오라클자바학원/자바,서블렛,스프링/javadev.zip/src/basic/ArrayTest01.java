package basic;

public class ArrayTest01 {

	public static void main(String[] args) {
//		int[] arr = new int[]{100, 200, 300};
		int[] arr = {100, 200, 300};
		
		for(int i=0; i<arr.length; i++) {
			System.out.println(arr[i]);
		}
	}

}
