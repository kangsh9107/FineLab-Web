package basic;

import java.util.Scanner;

public class OpTest08 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("정수를 입력하시면 짝수인지 홀수인지 알려 드립니다 : ");
		int a = sc.nextInt();
		
		System.out.println(a % 2 == 0 ? "Even" : "Odd");
		
		sc.close();
	}

}
