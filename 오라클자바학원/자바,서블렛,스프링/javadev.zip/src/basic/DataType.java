package basic;

public class DataType {

	public static void main(String[] args) {
		boolean b1 = false;
		System.out.println("b1 : " + b1);
		
		//char c = 'A';
		char c = 54620;
		System.out.println("c : " + c);
		
		byte b2 = 127;
		System.out.println("b2 : " + b2);
		
		short s = 32767;
		System.out.println("s : " + s);
		
		int i = 2147483647;
		System.out.println("i : " + i);
		
		//+-900경
		//정수는 기본적으로 int타입으로 인식한다. 따라서 뒤에 L을 붙여야 long타입으로 인식한다.
		long l1 = 2147483648L;
		System.out.println("l1 : " + l1);
		
		//8바이트 크기의 실수
		double d = 3.1415926535;
		System.out.println("d : " + d);
		
		//4바이트 크기의 실수
		//실수는 기본적으로 double타입으로 인식한다. 따라서 뒤에 F를 붙여야 float타입으로 인식한다.
		float f = 3.1415926535F;
		System.out.println("f : " + f);
		
		//escape sequence
		//특수문자로 키보드에서 제어기능을 담당하는 키들을 문자로 표현한 것.
		System.out.println("그가 말했다. \"안녕하세요~!\"");
		System.out.println("안녕하세요\n반갑습니다.");
		System.out.println("0\t1\t2\t3\t4");
		
	}

}
