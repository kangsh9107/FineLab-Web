package basic;

public class OpTest03 {

	public static void main(String[] args) {
		boolean a, b;
		
		//AND
//		a = true; b = true;
//		System.out.println(a && b);
//		a = true; b = false;
//		System.out.println(a && b);
//		a = false; b = false;
//		System.out.println(a && b);
		
		//OR
//		a = true; b = true;
//		System.out.println(a || b);
//		a = true; b = false;
//		System.out.println(a || b);
//		a = false; b = false;
//		System.out.println(a || b);
		
		//NOT
		a = true; b = true;
		System.out.println(!a);
		a = false; b = false;
		System.out.println(!a);
	}

}
