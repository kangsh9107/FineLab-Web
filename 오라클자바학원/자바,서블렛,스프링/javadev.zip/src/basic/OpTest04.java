package basic;

public class OpTest04 {

	public static void main(String[] args) {
		int a = 5;
//		++a; //a = a + 1; (prefix)
//		a++; //a = a + 1; (postfix)
		
//		int b = ++a; //a = a + 1;
//					 //b = a;
//		System.out.println(b);
		
//		int c = a++; //c = a;
//					 //a = a + 1;
//		System.out.println(c);
		
//		System.out.println(a++);
//		System.out.println(a);
//		System.out.println(++a);
	}

}
