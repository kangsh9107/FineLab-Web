package basic;

public class DoWhileTest01 {

	public static void main(String[] args) {
//		int sum = 0;
//		int i = 0;
//		while(i <= 1000) {
//			sum += i;
//			i += 3;
//		}
//		System.out.println("1부터 1000까지 3의 배수의 합은 : " + sum);
		
		//while문을 do~while문으로 변경
		int sum = 0;
		int i = 0;
		do {
			sum += i;
			i += 3;
		} while(i <= 1000);
		System.out.println("1부터 1000까지 3의 배수의 합은 : " + sum);
		
//		int sum = 0;
//		int i = 1;
//		do {
//			if(i % 3 == 0) sum += i;
//			i++;
//		} while(i <= 1000);
//		System.out.println("1부터 1000까지 3의 배수의 합은 : " + sum);
	}

}
