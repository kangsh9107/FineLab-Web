package basic;

public class WhileTest01 {

	public static void main(String[] args) {
//		for(int i=1; i<=3; i++) {
//			System.out.println("오라클자바");
//		}
//		System.out.println("종료");
		
		//for문을 while문으로 변경
		int i = 1;
		while(i <= 3) {
			System.out.println("오라클자바");
			i++;
		}
		System.out.println("종료");
	}

}
