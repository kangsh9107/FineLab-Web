package basic;

import java.util.Scanner;

public class SwitchTest02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int age = sc.nextInt();
		
		switch(age) {
		case 1:
			System.out.println("남자");
			break;
		case 2:
			System.out.println("여자");
			break;
		case 3:
			System.out.println("남자");
			break;
		case 4:
			System.out.println("여자");
			break;
		default:
			System.out.println("에러");
		}
		
		sc.close();
		
	}

}
