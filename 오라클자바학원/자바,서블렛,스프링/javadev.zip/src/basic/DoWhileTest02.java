package basic;

public class DoWhileTest02 {

	public static void main(String[] args) {
		//do~while문을 사용해 주사위를 2번 던져서 다른 숫자가 나오게 하시오.
		//드래그 후 우클릭 > Surround With > do
		int n1, n2;
		
		n1 = (int)(Math.random() * 6) + 1;
		do {
			n2 = (int)(Math.random() * 6) + 1;
		} while (n2 == n1);
		
		System.out.println(n1 + "," + n2);
	}

}
