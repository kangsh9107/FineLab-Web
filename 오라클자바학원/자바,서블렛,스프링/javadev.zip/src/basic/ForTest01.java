package basic;

public class ForTest01 {

	/*
	 * for(초기식; 조건식; 증감식) {
	 *   조건식이 참일 때 수행하는 문장
	 * }
	 */
	public static void main(String[] args) {
		for(int i=1; i<=3; i++) {
			System.out.println("오라클자바");
		}
		System.out.println("종료");
	}

}
