package basic;

public class MethodTest01 {

	public static void main(String[] args) {
		print();
		print(); //print메소드 정의하고 pr(메소드 명 어느정도)치고 컨트롤 + 스페이스로 쉽게 작성 가능
		print("son");
		print("ryu");
		
		int a = 7, b = 4;
		System.out.println(a + " + " + b + " = " + add(a, b));
		System.out.println(a + " - " + b + " = " + sub(a, b));
		System.out.println(a + " * " + b + " = " + mul(a, b));
		System.out.println(a + " / " + b + " = " + div(a, b));
		System.out.println(a + " % " + b + " = " + mod(a, b));
	}

	private static int mod(int a, int b) {
		return a % b;
	}

	private static int div(int a, int b) {
		return a / b;
	}
	
	private static int mul(int a, int b) {
		return a * b;
	}

	private static int sub(int a, int b) {
		return a - b;
	}

	private static int add(int a, int b) {
//		int c = a + b;
//		return c;
		return a + b;
	}

	//메소드 오버로딩(Overloading)
	private static void print(String name) {
		System.out.println("Hello " + name);
	}

	private static void print() {
		System.out.println("Hello world");
		return;
	}

}
