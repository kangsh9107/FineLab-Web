package oop08.exception;

public class ExceptionTest01 {
	
	public static void main(String[] args) {
		String str = null;
		
		//실행코드와 예외를 쓰레드로 처리하기 때문에 순서가 바뀌는 경우가 있다
		try {
			System.out.println(str.toString());
		} catch (NullPointerException e) {
			e.printStackTrace();
			System.out.println("NullPointerException 종료");
		} catch (Exception e) {
			//캐치 블록을 여러개 사용할 때는 상위 타입의 클래스를 아래쪽에 작성한다
			//상위 타입의 클래스를 위에 작성하면 거기서 다 걸리니까
			e.printStackTrace();
			System.out.println("Exception 종료");
		} finally {
			//예외 발생 유무와 관계없이 무조건 실행되는 블록
			System.out.println("finally 블록");
		}
		
		System.out.println("종료"); //예외처리를 하지 않은 곳에서 예외가 발생하면 해당 지점에서 프로그램이 중지된다
	}

}
