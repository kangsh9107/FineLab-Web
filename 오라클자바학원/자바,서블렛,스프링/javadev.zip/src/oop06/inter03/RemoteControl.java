package oop06.inter03;

public interface RemoteControl {

	public void powerOn();
	public void powerOff();
	public void channelUp();
	public void channelDown();
	
}
