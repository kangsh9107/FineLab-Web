package oop06.inter01;

public interface TV {
	
	public void turnOn(); //인터페이스는 어차피 다 추상클래스라서 abstract 생략해도 된다
	public void turnOff();
	public void channelUp();
	public void channelDwon();
	public void soundUp();
	public void soundDown();

}
