package oop06.inter01;

public class TVuser {
	
	public static void main(String[] args) {
//		LgTV tv = new LgTV();
//		tv.turnOn();
//		tv.channelUp();
//		tv.channelUp();
//		tv.channelUp();
//		tv.soundUp();
//		tv.soundUp();
//		tv.soundDown();
//		tv.turnOff();
		
//		STV tv = new STV();
//		tv.turnOn();
//		tv.channelUp();
//		tv.channelUp();
//		tv.channelUp();
//		tv.soundUp();
//		tv.soundUp();
//		tv.soundDown();
//		tv.turnOff();
		
		TV tv = new STV();
		tv.turnOn();
		tv.channelUp();
		tv.channelUp();
		tv.channelUp();
		tv.soundUp();
		tv.soundUp();
		tv.soundDown();
		tv.turnOff();
		
		System.out.println();
		
		TV tv2 = new LgTV();
		tv2.turnOn();
		tv2.channelUp();
		tv2.channelUp();
		tv2.channelUp();
		tv2.soundUp();
		tv2.soundUp();
		tv2.soundDown();
		tv2.turnOff();
	}

}
