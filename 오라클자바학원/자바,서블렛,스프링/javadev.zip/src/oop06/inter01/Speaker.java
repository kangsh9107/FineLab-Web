package oop06.inter01;

public interface Speaker {
	
	public void soundUp();
	public void soundDown();
	
}
