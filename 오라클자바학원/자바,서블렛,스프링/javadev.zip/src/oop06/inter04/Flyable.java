package oop06.inter04;

public interface Flyable {
	
	public void fly();

}
