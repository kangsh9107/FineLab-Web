package oop06.inter04;

public class FlyingCarTest {

	public static void main(String[] args) {
//		Car car = new FlyingCar();     //fly() 호출 불가
//		Flyable car = new FlyingCar(); //게터, 세터 접근 불가
		FlyingCar car = new FlyingCar();
		car.setSpeed(300);
		System.out.println(car.getSpeed());
		
		car.fly();
	}
	
}
