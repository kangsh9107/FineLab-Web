package oop06.inter05;

public class FlyingCarTest {

	public static void main(String[] args) {
//		Flyable car = new FlyingCar();  //drive() 호출 불가
//		Drivable car = new FlyingCar(); //fly() 호출 불가
		FlyingCar car = new FlyingCar();
		car.fly();
		car.drive();
	}
	
}
