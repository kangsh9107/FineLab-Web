package oop06.inter05;

public interface Drivable {
	
	public void drive();

}
