package oop06.inter05;

public interface Flyable {
	
	public void fly();

}
