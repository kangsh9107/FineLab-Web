package oop06.inter06;

public interface InterfaceC extends InterfaceA, InterfaceB {
	
	public void methodC();

}
