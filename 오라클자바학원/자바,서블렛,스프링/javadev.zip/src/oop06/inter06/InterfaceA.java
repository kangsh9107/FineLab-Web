package oop06.inter06;

public interface InterfaceA {
	
	public void methodA();

}
