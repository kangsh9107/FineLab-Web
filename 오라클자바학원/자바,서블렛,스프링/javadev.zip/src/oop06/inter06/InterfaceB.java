package oop06.inter06;

public interface InterfaceB {
	
	public void methodB();

}
