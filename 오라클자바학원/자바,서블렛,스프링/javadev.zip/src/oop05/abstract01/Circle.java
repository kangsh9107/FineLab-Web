package oop05.abstract01;

public class Circle extends Shape {

	int r = 10;
	
//	public void size() {
//		res = r * r * 3.14;
//	}
	
	//추상 클래스를 상속하기 때문에 반드시 area메소드를 구현해야 한다.
	@Override
	public void area() {
		res = r * r * 3.14;
	}
	
}
