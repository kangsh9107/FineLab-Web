package oop05.abstract01;

public class Rectangle extends Shape {

	int w = 10, h = 5;
	
	public void area() {
		res = w * h;
	}
	
}
