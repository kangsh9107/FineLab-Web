package oop05.abstract01;

//클래스 안에 추상 메소드가 한 개 이상 존재하면 추상 클래스
public abstract class Shape {

	double res;
//	public void area() {}
	
	//추상 메소드
	public abstract void area();
	
}
