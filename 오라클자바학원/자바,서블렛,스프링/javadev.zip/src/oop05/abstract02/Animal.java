package oop05.abstract02;

public abstract class Animal {

	public void eat() {
		System.out.println("맛있게 먹습니다.");
	}
	
	public abstract void sleep();
	
}
