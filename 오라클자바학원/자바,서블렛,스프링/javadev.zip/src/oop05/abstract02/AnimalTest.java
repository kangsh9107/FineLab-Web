package oop05.abstract02;

public class AnimalTest {

	public static void main(String[] args) {
		Animal a = new Dog();
		a.sleep();
		
		a = new Cat();
		a.sleep();
		
		a = new Tiger();
		a.sleep();
	}

}
