package oop10.api;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ApiTest01 {
	
	public static void main(String[] args) {
		Set<String> set = new HashSet<>();
		set.add("송혜교");
		set.add("박보영");
		set.add("송혜교");
		set.add("서현진");
		set.add("김고은");
//		set.add(343);
//		set.add(123.13);
		
		System.out.println(set.size());
		
		Iterator<String> iter = set.iterator();
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
	}

}
