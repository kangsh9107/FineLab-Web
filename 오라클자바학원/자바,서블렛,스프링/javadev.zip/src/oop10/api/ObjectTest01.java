package oop10.api;

class Point {
	
}

public class ObjectTest01 {
	
	public static void main(String[] args) {
		Point pt = new Point();
		System.out.println("클래스 이름 : " + pt.getClass());
		System.out.println("해시 코드 : " + pt.hashCode());
		System.out.println("인스턴스 참조값 : " + pt.toString()); //클래스명@해시 코드 16진수
		
		Point pt2 = new Point();
		System.out.println("클래스 이름 : " + pt2.getClass());
		System.out.println("해시 코드 : " + pt2.hashCode());
		System.out.println("인스턴스 참조값 : " + pt2.toString()); //클래스명@해시 코드 16진수
	}
	
}
