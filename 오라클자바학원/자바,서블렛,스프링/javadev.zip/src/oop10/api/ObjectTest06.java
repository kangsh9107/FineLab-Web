package oop10.api;

public class ObjectTest06 {
	
	public static void main(String[] args) {
		Integer i = 10;
		Object obj = i; //up casting
		
		Integer n = (Integer) obj; // down casting
		int m = (Integer) obj;
		
		System.out.println(n + "을 2진수로 바꾸면 " + Integer.toBinaryString(m));
		System.out.println(n + "을 8진수로 바꾸면 " + Integer.toOctalString(m));
		System.out.println(n + "을 16진수로 바꾸면 " + Integer.toHexString(m));
	}

}
