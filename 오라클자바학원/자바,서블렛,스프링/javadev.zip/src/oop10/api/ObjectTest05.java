package oop10.api;

public class ObjectTest05 {
	
	public static void main(String[] args) {
		Integer i = 10; //오토 박싱(auto boxing)
		System.out.println(i);
		
		int n = i; //오토 언박싱(auto unboxing)
	}

}
