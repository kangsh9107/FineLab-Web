package oop10.api;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ApiTest02 {
	
	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("송혜교");
		list.add("박보영");
		list.add("송혜교");
		list.add("서현진");
		list.add("김고은");
		
		System.out.println(list.size());
		
		Iterator<String> iter = list.iterator();
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
		
		System.out.println("=========");
		for(int i=0; i<list.size(); i++) {
			System.out.println(list.get(i));
		}
		
		System.out.println("=========");
		for(String l : list) {
			System.out.println(l);
		}
	}

}
