package oop09.thread;

public class ThreadTest02 extends Thread {
	
	public static void main(String[] args) {
		ThreadTest02 t = new ThreadTest02();
		t.start(); //스레드를 생성하고, 스레드가 run() 메소드를 호출한다
		
		for(int i=1; i<=5; i++) {
			System.out.println("main : " + i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void run() {
		for(int i=1; i<=5; i++) {
			System.out.println("run : " + i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
