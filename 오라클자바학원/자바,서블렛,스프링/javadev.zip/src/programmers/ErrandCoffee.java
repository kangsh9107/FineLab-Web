package programmers;

public class ErrandCoffee {

	//https://school.programmers.co.kr/learn/courses/30/lessons/181837
	public static void main(String[] args) {
		ErrandCoffee ec = new ErrandCoffee();
		
		String[] order1 = {"cafelatte", "americanoice", "hotcafelatte", "anything"};
		System.out.println(ec.solution(order1));
		
		String[] order2 = {"americanoice", "americano", "iceamericano"};
		System.out.println(ec.solution(order2));
	}

	private int solution(String[] order) {
        int answer = 0;
        
        for(int i=0; i<order.length; i++) {
            if(order[i].contains("americano")) {
                answer += 4500;
            } else if(order[i].contains("cafelatte")) {
                answer += 5000;
            } else {
                answer += 4500;
            }
        }
        
        return answer;
	}

}
