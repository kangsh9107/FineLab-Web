package programmers;

public class MakeL {

	//https://school.programmers.co.kr/learn/courses/30/lessons/181834
	public static void main(String[] args) {
		MakeL ml = new MakeL();
		
		String myString1 = "abcdevwxyz";
		System.out.println(ml.solution(myString1));
		
		String myString2 = "jjnnllkkmm";
		System.out.println(ml.solution(myString2));
	}

	private String solution(String myString) {
		String answer = "";
		answer = myString.replaceAll("[a-k]", "l");
		return answer;
	}

}
