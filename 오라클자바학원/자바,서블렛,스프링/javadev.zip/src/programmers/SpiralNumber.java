package programmers;

public class SpiralNumber {

	//https://school.programmers.co.kr/learn/courses/30/lessons/181832
	public static void main(String[] args) {
		SpiralNumber sn = new SpiralNumber();
		
		int n1 = 4;
		System.out.println(sn.solution(n1));
		
//		int n2 = 5;
//		System.out.println(sn.solution(n2));
	}

	private int[][] solution(int n) {
		int[][] answer = new int[n][n];
		
		int cnt = 1;
		for(int i=0; i<answer.length; i++) {
			for(int j=0; j<answer[i].length; j++) {
				answer[i][j] = cnt;
				cnt++;
			}
		}
		
		print(answer);
		return answer;
	}
	
	private void print(int[][] answer) {
		for(int i=0; i<answer.length; i++) {
			for(int j=0; j<answer[i].length; j++) {
				System.out.print(answer[i][j] + "\t");
			}
			System.out.println();
		}
	}

}
