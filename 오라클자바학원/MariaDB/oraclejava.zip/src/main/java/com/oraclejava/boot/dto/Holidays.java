package com.oraclejava.boot.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Table(name = "holidays")
@Entity
@Getter
@Setter
public class Holidays {

	@Id
	@Column(name = "holiday_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer holidayId;
	String holidayName;
	String holidayDate;
	String createdBy;
	String createdAt;
	String updatedBy;
	String updatedAt;
	String deletedBy;
	String deletedAt;
	Integer version;
	
}
