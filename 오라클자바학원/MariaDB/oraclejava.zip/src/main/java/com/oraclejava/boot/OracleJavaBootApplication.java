package com.oraclejava.boot;

import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class OracleJavaBootApplication {

	public static void main(String[] args) throws IOException {
		ConfigurableApplicationContext ctx = SpringApplication.run(OracleJavaBootApplication.class, args);
		System.out.println("������ ��Ʈ ������...");
		
		System.in.read();
		
		ctx.close();
	}

}
