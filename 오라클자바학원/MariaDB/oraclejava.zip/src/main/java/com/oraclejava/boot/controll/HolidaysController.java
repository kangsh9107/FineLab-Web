package com.oraclejava.boot.controll;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oraclejava.boot.dto.Holidays;
import com.oraclejava.boot.service.HolidaysService;

@Controller
@RequestMapping(value = "/holidays")
public class HolidaysController {

	private final Logger logger = LoggerFactory.getLogger(HolidaysController.class);
	
	@Autowired
	HolidaysService holidaysService;
	
	@GetMapping(value = "/select")
	public String selectAll(Model model) {
		logger.info("selectAll");
		
		List<Holidays> holidays = holidaysService.findAll();
		model.addAttribute("holidays", holidays);
		return "holidaysSelect";
	}
	
}
