package com.oraclejava.boot.controll;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oraclejava.boot.dto.User;
import com.oraclejava.boot.service.UserService;

@Controller
@RequestMapping(value = "/users")
public class UserController {

	private final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	UserService userService;
	
	@GetMapping(value = "/select")
	public String selectAll(Model model) {
		logger.info("selectAll");
		
		List<User> users = userService.findAll();
		model.addAttribute("users", users);
		return "usersSelect";
	}
	
}
