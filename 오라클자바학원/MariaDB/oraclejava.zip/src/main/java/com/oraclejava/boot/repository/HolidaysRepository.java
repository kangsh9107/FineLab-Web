package com.oraclejava.boot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.oraclejava.boot.dto.Holidays;

public interface HolidaysRepository extends JpaRepository<Holidays, Integer> {
	
	@Query(value = "select * from holidays", nativeQuery = true)
	List<Holidays> selecAll();

}
